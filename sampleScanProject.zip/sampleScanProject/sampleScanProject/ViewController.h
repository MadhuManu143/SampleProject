//
//  ViewController.h
//  sampleScanProject
//
//  Created by madhu on 28/04/15.
//  Copyright (c) 2015 Pajworld Software Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ZXingObjC/ZXingObjC.h>
@interface ViewController : UIViewController


@end

